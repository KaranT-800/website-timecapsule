<?php
// Connection to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "userdb";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];

    // Check if the username or email already exist
    $check_query = "SELECT * FROM users WHERE username = '$username' OR email = '$email'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        echo "Username or email already taken.";
    } else {
        // Insert the new user into the database
        $insert_query = "INSERT INTO users (username, email) VALUES ('$username', '$email')";
        if ($conn->query($insert_query) === TRUE) {
            header('Location:http://localhost/test/index2.php');
        } else {
            echo "Error: " . $insert_query . "<br>" . $conn->error;
        }
    }
}
$conn->close();
?>
